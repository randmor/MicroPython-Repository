
========================================================
Notes on using I2C_2004_LCDs on the BBC Micro:bit board
========================================================



With the Microbit's limited memory capacity, development of these two 
demo programs frequently ran up against MemoryErrors. I assume most of
 these errors were because I was running up against some unseen memory boundry. 
This problem is even worse with a second I2C_2004_LCD connected.

 By using programming techniques like minimizing comments, minimizing 
variable name lengths, and by limiting the number of classes/methods I 
was using from the "microbit" library module, I was able to create two 
demo programs which show how to use the new "lcd2004.py" driver. These
 two demo files are:



    1.) mb_lcd2004_Demo1.py    (Demos a single I2C_2004_LCD display module)


    2.) mb_lcd2004_Demo2.py    (Demos two I2C_2004_LCD display modules)



I have attempted a 3rd demo program to see if I also could get a I2C_1602_LCD (2x16)
display module to work with this 2004_LCD driver (as I was able to do with the "ESP" 
(ESP8266/ESP32) version of MicroPython). However, the "microbit" library's "i2c" class is 
apparantly different enough from the ESP "machine" library's "I2C" class that 
I was unable to make the 1602_LCD work on the Microbit. So, if you need to
 use a I2C_1602_LCD you will need to use Xioziyang's original "lcd1602.py"
driver.



Memory limitations also make supporting more than two I2C_LCDs nearly impossible
 to do. Even with a single I2C_LCD, doing other useful work besides displaying
 output to the LCD display is quite limited. For any serious work, you should 
drop the Microbit and switch over to an ESP32 based MCU board. You will find it has much
 more memory and most of your "MemoryErrors" will be a thing of the past. These "
ESP" MCU board are, however, more of a challenge to program in other ways and do not include many of the unique features of the BBC Microbit board that most of us have come to enjoy. Too bad they don't try to do a "Version 2 BBC Microbit" based around the ESP32 combining older Microbit features with newer ESP32 features. Anyone looking for a good "GoFundMe project"?


==================

Interfacing Notes:

==================





The BBC Microbit has just one standard I2C port:



     1.) I2C Port "Pin-Outs":
            
            SCL = Pin-19      Accessible on the edge connector (*)

            SDA = Pin-20      Accessible on the edge connector (*)



     (*) It's best to use a Microbit "breakout board" to access

         the I2C pins shown above. Several companies make these

         boards and your BBC Micro:bit supplier should be able
 
         to recommend and supply you with a good one.



I have included a photo of how my Microbit was set up with two I2C_2004_LCDs.
 This photo is in the file called "photo.png". 
In the photo, you can see how the I2C SCL and SDA signals (pins 19 and 20) are routed to the MB-102 solderless breadboard where these 2 signal lines connect to the same signal lines for the two LCD_2004_LCd displays. Refer to this photo is you have any questions about the wiring that I don't address in this document.

Each I2C_2004_LCD must have a separate (unique) I2C address.


 These "I2C_2004_LCD" display modules include an "I2C Backpack" board which provides 
the I2C interface for the otherwise parallel interface of the display 
module. If your 2004_LCD does not include this I2C Backpack, then you 
will need to order one and solder it to the back of the display module in the pin holes provided for the parallel interface.

WARNING: Be sure NOT to press the Backpack 
board up against the 2004_LCD display module as you may short out
 the two boards, causing them to fail. I recommend a 5mm gap with 
a piece of thin cardboard to act as an insulator between the two boards 
when you solder the Backpack board to the 2004_LCD board. 








=======================

Voltage Considerations:

=======================



The I2C_2004_LCD (like the I2C_1602_LCD) was designed to work with
 "TTL" (+5VDC) voltage levels and the Microbit does not provide +5V
 on its edge connector. This means that with the Microbit, you will 
have to power the LCD display module with an external +5V power supply.
 What I use is a breadboard friendly dual voltage (+5V, +3.3V) regulator 
board from "YwRobot" (a Chinese supplier) along with a 120VAC_to_+9VDC 
power adapter ("wall wart") to supply the +5VDC I need for the LCD 
display modules. See the "photo.png" image file for a picture of my setup to help clarify my hardware setup.



Note: Voltage level shifters are NOT required on the I2C signal lines 
(SCL and SDA) to make these LCD displays work well with the Microbit 
(or most ESP8266/ESP32 boards).








======================================================
Changing the I2C Address for Your Second I2C_2004_LCD 
======================================================




These I2C Backpacks also have three pairs of jumper pads which you can
 use to change the I2C address for your second 2004_LCD. These 3 pairs 
of jumper pads are labled "A0", "A1" and "A2". They are located just 
under the "little blue box" potentiometer (variable resistor) used to adjust 
the contrast of the display. 
A thin piece of bare wire will need to be oriented vertically across 
one of these pairs of jumper blocks, say "A0". (You could also just 
solder a "blob" of solder across these two pads if that is easier for 
you.) 



Once the jumper pads have been "bridged", the I2C address for the device will change 
as follows: the binary number formed by "A0", "A1" and "A2" is 
SUBTRACTED from (not added to) the default I2C address of the card.
 When I did this for my second I2C_2004_LCD, I bridged both "A1" and "A2", which created 
a binary "3" (011) which when subtracted from "0x27" yielded "0x24". I then
 had to plug this number into the source code of my second demo program ("mb_lcd2004_Demo2.py"), 
which supports two I2C_2004_LCDs. Here's what that section of code looks like:

    from microbit import pin19, pin20, i2c, sleep, display
    import lcd2004

    myI2C = i2c.init(freq=100000, sda=pin20, scl=pin19)
    L1 = lcd2004.LCD2004(myI2C, 0x27)
    L2 = lcd2004.LCD2004(myI2C, 0x24)

The LCD2004 objects are being called "L1" and "L2". Assuming you are using the default "0x27" for the first LCD diplay module, and need to change the second LCD display module's I2C address, you can replace "0x24" with whatever I2C address you configured (jumpered) the second LCD to be. Again, for me it was "0x24", which is why that number appears here in the 
source code. 

Another "gotcha" is that some I2C Backpacks default to "0x27" 
(like mine did), and others default to "0x3f". If yours default to "0x3f", then you will have to change the line above (L1 = ...) as well. Then save and flash the dem program to see if it works.

Note: The original I2C controller chip used in the I2C Backpack board was the "PCF8574T" which defaults to an I2C address of 0x27. A second version of this I2C controller chip is the "PCF8574AT" which defaults to an I2C address of 0x3F. If you are lucky, you might be able to read the part number silk-screened (printed) on top of the controller chip on the backpack. This can clue you into what the I2C address (or address range) the board will be using. The two I2c address ranges are:

    Range 1: 0x20 thru 0x27 (defaults to 0x27) [I2C Backpacks w/"PCF8574T" chip]

    Range 2: 0x38 thru 0x3F (defaults to 0x3f) [I2C Backpacks w/"PCF8574AT" chip]



================================
The I2C Address Scanner Program
================================

Because the I2C address of the second LCD display, with all the soldering and subtracting binary numbers from the default hex I2C address can be a bit confusing, I have included a utility program you can run to see what I2C devices are on your Microbit's I2C bus. If you run this utility, you will discover two other I2C devices that are already on the I2C bus: the Accelerometer and the Magnetometer (compass). The exact I2C address displayed for these two "on-board" devices depend upon which revision of the MicroBit board you have. Here's that information:

I2C Addresses Used on the BBC Microbit:
	                                    Acceleroeter	Magnetometer
    micro:bit v1.3 (MMA8653+MAG3110)	    0x1D (0x3A/0x3B)	0x0E (0x1C/0x1D)
    micro:bit variant 1 (LSM303AGR)	    0x19 (0x32/0x33)	0x1E (0x3C/0x3D)
    micro:bit variant 2 (FXOS8700CQ)	    0x1E (0x3C/0x3D)	0x1E (0x3C/0x3D)

If you add one or two I2C_2004_LCDs to your Microbit circuit, then this I2C Address Scanner utility will identify them based on the address ranges shown at the end of the section above. If you add some other I2C device, the scanner will detect the I2C address, but will identify it as "an unknown (unexpected) I2C device". This scanner program uses the Microbit's 5x5 LED matrix display to scroll the text output, so you may have trouble catching all the information as it scrolls by. Just re-run the program a few times by pressing the Microbit's reset button. For details on how the program works, look at the source code for the scanner in the file called "i2c_Address_Scanner.py".

Enjoy...

EOF


