#
# Microbit I2C_2004_LCD Demo #2
#
# Testing with two I2C_2004_LCDs.
# Program requires the new "lcd2004.py" Microbit driver.
#
# Authors:  shaoziyang  (2018.2)
#           w.moore     (2019.7)
#
# Suffering frequent MemoryErrors due to Microbit memory limitations.
#

from microbit import pin19, pin20, i2c, sleep, display
import lcd2004

myI2C = i2c.init(freq=100000, sda=pin20, scl=pin19)
L1 = lcd2004.LCD2004(myI2C, 0x27)
L2 = lcd2004.LCD2004(myI2C, 0x24)

def clrScreens():
    L1.clear()
    L2.clear()
    sleep(500)
    L1.puts("LCD#1", 15, 0)
    L2.puts("LCD#2", 15, 0)
    sleep(500)

def toggleBacklights():
    L1.backlight(0)
    L2.backlight(0)
    sleep(2500)
    L1.backlight(1)
    L2.backlight(1)
    sleep(2500)

s1 = "Hello, World!"
s2 = "0123456789ABCDEFwxyz"
s3 = "abcdefghijklmnopqrst"
s4 = "ABCDEFGHIJKLMNOPQRST"

while True:
    display.scroll("I2C_2004_LCD Demo 2")
    clrScreens()
    sleep(2000)

    # Display 4 strings ==> LCD#1
    L1.puts(s1, 0, 0)
    L1.puts(s2, 0, 1)
    L1.puts(s3, 0, 2)
    L1.puts(s4, 0, 3)
    sleep(2000)

    # Display 4 strings ==> LCD#1
    L2.puts(s1, 0, 0)
    L2.puts(s2, 0, 1)
    L2.puts(s3, 0, 2)
    L2.puts(s4, 0, 3)
    sleep(2000)

    clrScreens()

    # Here's a nice "line-by-line" effect:
    L1.puts(s1, 0, 0)
    L2.puts(s1, 0, 0)
    L1.puts(s2, 0, 1)
    L2.puts(s2, 0, 1)
    L1.puts(s3, 0, 2)
    L2.puts(s3, 0, 2)
    L1.puts(s4, 0, 3)
    L2.puts(s4, 0, 3)
    sleep(2000)

    clrScreens()

    # Here's a nice "character-by-character" effect:
    for i in range(0, len(s1)):
        L1.puts(s1[i], i, 0)
        L2.puts(s1[i], i, 0)
    sleep(2000)

    for i in range(0,20):
        L1.puts(s2[i], i, 1)
        L2.puts(s2[i], i, 1)
    sleep(2000)

    for i in range(0,20):
        L1.puts(s3[i], i, 2)
        L2.puts(s3[i], i, 2)
    sleep(2000)

    for i in range(0,20):
        L1.puts(s4[i], i, 3)
        L2.puts(s4[i], i, 3)
    sleep(2000)

    # Signal start of shift tests...
    toggleBacklights()

    # Shift right test:
    for i in range(0, 20):
        L1.shr()
        L2.shr()
        sleep(500)
    sleep(4000)
    for i in range(0, 20):
        L1.shr()
        L2.shr()
        sleep(500)
    sleep(3000)

    # Shift left test:
    for i in range(0, 20):
        L1.shl()
        L2.shl()
        sleep(500)
    sleep(4000)
    for i in range(0, 20):
        L1.shl()
        L2.shl()
        sleep(500)
    sleep(3000)

    # Signal end of loop...
    L1.clear()
    L2.clear()
    toggleBacklights()