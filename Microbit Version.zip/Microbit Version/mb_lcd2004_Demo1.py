#
# Microbit I2C_2004_LCD Demo 1
#
# Testing with one I2C_2004_LCD.
# Program requires the new "lcd2004.py" Microbit driver.
#
# Authors:  shaoziyang  (2018.2)
#           w.moore     (2019.7)
#
# Suffering frequent MemoryErrors due to Microbit memory limitations.
#

from microbit import pin19, pin20, i2c, sleep, display
import lcd2004

myI2C = i2c.init(freq=100000, sda=pin20, scl=pin19)
L1 = lcd2004.LCD2004(myI2C, 0x27)

s1 = "Hello, World!       "
s2 = "0123456789ABCDEFwxyz"
s3 = "abcdefghijklmnopqrst"
s4 = "ABCDEFGHIJKLMNOPQRST"

while True:
    # Clear Screen
    L1.clear()
    sleep(1000)

    display.scroll("I2C_2004_LCD Demo 1")

    # Display 4 lines of text
    L1.puts("Hello, Micro:bit!   ", 0, 0)
    L1.puts(s2, 0, 1)
    L1.puts(s3, 0, 2)
    L1.puts(s4, 0, 3)
    sleep(3000)

    L1.clear()
    sleep(1000)

    # Backlight off/on test
    L1.puts("Backlight Test", 0, 0)
    sleep(2000)
    L1.puts("Backlight off.", 0, 1)
    sleep(2000)
    L1.backlight(0)
    sleep(2000)
    L1.puts("Backlight on. ", 0, 1)
    sleep(2000)
    L1.backlight(1)
    sleep(2000)
    L1.puts("Test done.", 0, 3)
    sleep(3000)

    L1.clear()
    sleep(1000)

    # Text off/on test
    L1.puts("Text Off/On Test", 0, 0)
    sleep(2000)
    L1.puts("All text 'off'. ", 0, 1)
    sleep(2000)
    L1.off()
    sleep(2000)
    L1.puts("All text 'on'.  ", 0, 1)
    sleep(2000)
    L1.on()
    sleep(2000)
    L1.puts("Test done.", 0, 3)
    sleep(3000)

    L1.clear()
    sleep(1000)

    # Display 4 lines of text one line at a time char by char
    for i in range(0, len(s1)):
        L1.puts(s1[i], i, 0)
    sleep(2000)
    for i in range(0,20):
        L1.puts(s2[i], i, 1)
    sleep(2000)
    for i in range(0,20):
        L1.puts(s3[i], i, 2)
    sleep(2000)
    for i in range(0,20):
        L1.puts(s4[i], i, 3)
    sleep(3000)

    # Shift right test
    for i in range(0, 20):
        L1.shr()
        sleep(500)
    sleep(4000)
    for i in range(0, 20):
        L1.shr()
        sleep(500)
    sleep(3000)

    # Shift left test
    for i in range(0, 20):
        L1.shl()
        sleep(500)
    sleep(4000)
    for i in range(0, 20):
        L1.shl()
        sleep(500)
    sleep(3000)