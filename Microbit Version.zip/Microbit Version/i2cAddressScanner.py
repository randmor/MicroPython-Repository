#
# MicroPython I2C Address Scanner for the BBC Microbit Board
#

from microbit import *

mbI2C = i2c.init(freq=100000, sda=pin20, scl=pin19)

# Scan the I2C bus for any I2C devices
display.scroll("Scanning...")
devices = i2c.scan()
sleep(2000)

# Display the number of I2C addresses found
numDevices = len(devices)
display.scroll("Number of I2C addresses found = ")
display.show(str(numDevices))
sleep(3000)

# Display what I2C addresses were found and the device
# which it should be associated with.
if numDevices > 0:
    for device in devices:
        display.scroll("I2C Address: " + str(hex(device)))
        if device == 0x1d:
            display.scroll("which is the on-board Accelerometer")
        elif device == 0xe:
            display.scroll("which is the on-board Magnetometer")
        elif device == 0x19:
            display.scroll("which is the on-board Accelerometer")
        elif device == 0x1e:
            display.scroll("which may be the on-board Magnetometer/Accelerometer")
        elif device >= 0x20 and device <= 0x27:
            display.scroll("which should be an I2C_LCD display with a PCF8574T I2C controller chip.")
        elif device >= 0x38 and device <= 0x3f:
            display.scroll("which should be an I2C_LCD display with a PCF8574AT I2C controller chip.")
        else:
            display.scroll("which is an unknown (unexpected) I2C device.")
        sleep(3000)
    display.scroll("Done.")

# EOF