#
# My Animation Program Version 2
#
# In Version 2, I added some code to make the images appear in some
# random order. Adding some more images to myFrames[] and a bit of
# code modification should make for more interesting animations.
# Maybe with Version 3, I'll try this idea.
#
#
# Code generated from my EduBlocks program called "myAnimationV1.xml"
#
# Program defines an array of five user defined images that are played
# sequentially forwards and the sequentialy backwards ad infinitum
# resulting in an interesting pattern of bits moving on the display.
#
# Pay attention to the two "for" loops and how I made the code advance
# through the array, and then made the code reverse through th array
# by changing the arguments in the range() function.
#
# Also notice how I used the boolean variable "animationOn" with
# the loop "while animationOn" along with "button_a" and "button_b"
# to turn-on and turn-off the animation, respectively.
#
# This code has been "cleaned up" to pass the Mu Editor's Check feature
# and a lot of comments have been added to make reading the code easier
# for students and other programmers to understand.

# Filename = "myAnimationV2.py"

from microbit import *
from random import randint

# Define 5 user-defined images to use in our animation:
frame1 = Image("22222:20002:20002:20002:22222")
frame2 = Image("22222:20002:20902:20002:22222")
frame3 = Image("22222:20902:29092:20902:22222")
frame4 = Image("22222:29092:20902:29092:22222")
frame5 = Image("22222:29992:29992:29992:22222")

# Create an array of these 5 images
myFrames = []
myFrames.append(frame1)
myFrames.append(frame2)
myFrames.append(frame3)
myFrames.append(frame4)
myFrames.append(frame5)

# Initialize an array to control the order of the slides
# in the annimation sequence.
order = [0, 1, 2, 3, 4]

# Define a standard delay of 1/2 second
delay = 500

# Display title of program
display.scroll("My Animation Program v2")
sleep(delay)

animationOn = False

while True:	# Outer while loop

    # Randomize the order (using minimal logic while proving concept)
    for i in range (0, 5):
        order[i] = randint(0,4)

    # Prompt user to press button "A"
    display.show(Image.ARROW_W)
    sleep(delay)

    # Check if user pressed button "A"
    if button_a.is_pressed():
        animationOn = True	# He did, so turn-on our "flag"

    while animationOn: 		# Inner while loop, runs only if our "flag" is True

        # Advance through our array of images, displaying one at time.
        for img in range(0, len(myFrames), 1):
            # Check it user wants to quit the animation
            if button_b.is_pressed():
                animationOn = False	# He did, so turn-off our "flag"
                continue
            display.show(myFrames[order[img]])
            sleep(delay)

        # Reverse through our array of images, displaying one at time.
        for img in range(len(myFrames) - 1, 0, -1):
            # Check it user wants to quit the animation
            if button_b.is_pressed():
                animationOn = False	# He did, so turn-off our "flag"
                continue
            display.show(myFrames[order[img]])
            sleep(delay)

    # Clean up display after "inner whie loop".
    display.clear()
    sleep(delay)

# EOF