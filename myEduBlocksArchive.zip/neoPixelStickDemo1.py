#
# NeoPixel-Stick Demo 1
#
# This NeoPixel Demo program was written for use with the
# AdaFruit 8-Pixel NeoPixel Stick. However, the program
# can easily be modified to support other NeoPixel devices,
# including sticks, rings and matricies. These smart RGB LEDs
# are all controlled by an embedded WS2812B controller chip
# that allows these special LEDs to be daisy chained in long
# chains where each chain is driven by a single GPIO pin.
# The WS2812B chip supports what is essentially a "1-wire"
# communications protocol, and on the Microbit/MicoPython
# platform, the interface software is all contained in the
# "neopixel" library module.
#
# Be aware that "NeoPixel" is a registered trademark of AdaFruit
# Insdustries and that there is no single universally accepted
# name for these LED devices. They go by many names, including
# "Zip LEDs", "WS2812B LEDs", "smart RGB LEDs", and the like.
# If the technical info for the devices refers to the WS2812B
# controller chip inbedded in the RGB LED, then chances are that
# it one of these smart RGB LEDs equivalent to a NeoPixel.
#
# A standard RGB LED has 4 leads: red input, green input, blue
# input and common ground (GND). To drive a single RGB LED, your
# microcontroller will need to use 3 GPIO pins plus GND. Since
# the number of GPIO pins is such a limited valuable resource,
# before NeoPixels came along, very few RGB LEDs were used per
# microcontroller. The cool thing about NeoPixels (and their
# equivalents) is that you can chain together up to 256 of
# these special LEDs and use up just a single GPIO pin on your
# microcontroller. However, the Microbit has a particularily
# weak power supply, and officially, you should not drive more
# than 8 at full brightness unless you also use an external
# power source other than the Microbit to power them. I have
# seen display boards like the Proto-PIC Micro:Pixel which has
# 32 ZIP LEDs, and they seem to work well enough. But, then I'm
# usually driving them at 1/8 brightness. So, be warned.
#
# Filename: "neoPixelStickDemo1.py"

from microbit import *
import random
import neopixel

numLEDs = 8        # Number of NeoPixel LEDs on device
mb = 32            # Maximum brightness setting
delay = 333        # Sleep delay to view next lit neopixel

colors = []
colors.append((0, 0, 0))	    # Black
colors.append((mb, 0, 0))	    # Red
colors.append((mb, mb, 0))	    # Yellow
colors.append((mb, mb//2, 0))	    # Orange
colors.append((0, mb, 0))	    # Green
colors.append((0, mb, mb))	    # Cyan
colors.append((0, 0, mb))	    # Blue
colors.append((mb//3, 0, 2*mb//2))  # Purple
colors.append((mb, 0, mb))	    # Magenta (pink)
colors.append((mb, mb, mb))	    # White

display.scroll("NeoPixel Demo")

np = neopixel.NeoPixel(pin0, numLEDs)

while True:

    # Advance
    for i in range(0, numLEDs):
        np[i] = colors[random.randint(1,9)]  # Skips black
        np.show()
        sleep(delay)

    # Retreat
    for i in range(numLEDs-1,0,-1):
        np[i] = colors[random.randint(1,9)]  # Skips black
        np.show()
        sleep(delay)

# EOF