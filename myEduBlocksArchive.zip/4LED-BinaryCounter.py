#
# 4-LED Binary Counter (can count from 0 to 15)
#
# Instead of using additioanl external LEDs to enlarge my binary
# counter, I thought I could use the display.set_pixel() method
# and display the binary counter using the five LEDs in the top
# row of the 5x5 red LED matrix display. However, after making a
# 4 bit binary counter that can count from 0 to 15, I saw how as
# I add an additional bit to my counter I was practically doubling
# the length of my program. Seems like there must be a better way
# to do this, so I'll have to think about it a while. This program
# will show a binary coubt from 0 to 15 as well as use button "A"
# to increment the counter, button "B" to decrement the counter,
# and both buttons "A" and "B" at the seame time to reset the
# counter to zero.
#
# There is a EduBlocks version of this program called
# "4LED-BinaryCounter.xml"
#
# Filename: "4LED-BinaryCounter.py"


from microbit import *

counter=0

while True:
  if counter == 0:
    display.set_pixel(4,0,0)
    display.set_pixel(3,0,0)
    display.set_pixel(2,0,0)
    display.set_pixel(1,0,0)
    # display.set_pixel(0,0,0)

  elif counter == 1:
    display.set_pixel(4,0,9)
    display.set_pixel(3,0,0)
    display.set_pixel(2,0,0)
    display.set_pixel(1,0,0)
    # display.set_pixel(0,0,0)

  elif counter == 2:
    display.set_pixel(4,0,0)
    display.set_pixel(3,0,9)
    display.set_pixel(2,0,0)
    display.set_pixel(1,0,0)
    # display.set_pixel(0,0,0)

  elif counter == 3:
    display.set_pixel(4,0,9)
    display.set_pixel(3,0,9)
    display.set_pixel(2,0,0)
    display.set_pixel(1,0,0)
    # display.set_pixel(0,0,0)

  elif counter == 4:
    display.set_pixel(4,0,0)
    display.set_pixel(3,0,0)
    display.set_pixel(2,0,9)
    display.set_pixel(1,0,0)
    # display.set_pixel(0,0,0)

  elif counter == 5:
    display.set_pixel(4,0,9)
    display.set_pixel(3,0,0)
    display.set_pixel(2,0,9)
    display.set_pixel(1,0,0)
    # display.set_pixel(0,0,0)

  elif counter == 6:
    display.set_pixel(4,0,0)
    display.set_pixel(3,0,9)
    display.set_pixel(2,0,9)
    display.set_pixel(1,0,0)
    # display.set_pixel(0,0,0)

  elif counter == 7:
    display.set_pixel(4,0,9)
    display.set_pixel(3,0,9)
    display.set_pixel(2,0,9)
    display.set_pixel(1,0,0)
    # display.set_pixel(0,0,0)

  elif counter == 8:
    display.set_pixel(4,0,0)
    display.set_pixel(3,0,0)
    display.set_pixel(2,0,0)
    display.set_pixel(1,0,9)
    # display.set_pixel(0,0,0)

  elif counter == 9:
    display.set_pixel(4,0,9)
    display.set_pixel(3,0,0)
    display.set_pixel(2,0,0)
    display.set_pixel(1,0,9)
    # display.set_pixel(0,0,0)

  elif counter == 10:
    display.set_pixel(4,0,0)
    display.set_pixel(3,0,9)
    display.set_pixel(2,0,0)
    display.set_pixel(1,0,9)
    # display.set_pixel(0,0,0)

  elif counter == 11:
    display.set_pixel(4,0,9)
    display.set_pixel(3,0,9)
    display.set_pixel(2,0,0)
    display.set_pixel(1,0,9)
    # display.set_pixel(0,0,0)

  elif counter == 12:
    display.set_pixel(4,0,0)
    display.set_pixel(3,0,0)
    display.set_pixel(2,0,9)
    display.set_pixel(1,0,9)
    # display.set_pixel(0,0,0)

  elif counter == 13:
    display.set_pixel(4,0,9)
    display.set_pixel(3,0,0)
    display.set_pixel(2,0,9)
    display.set_pixel(1,0,9)
    # display.set_pixel(0,0,0)

  elif counter == 14:
    display.set_pixel(4,0,0)
    display.set_pixel(3,0,9)
    display.set_pixel(2,0,9)
    display.set_pixel(1,0,9)
    # display.set_pixel(0,0,0)

  elif counter == 15:
    display.set_pixel(4,0,9)
    display.set_pixel(3,0,9)
    display.set_pixel(2,0,9)
    display.set_pixel(1,0,9)
    # display.set_pixel(0,0,0)

  else:

    for i in range(3):
      display.set_pixel(4,0,9)
      display.set_pixel(3,0,9)
      display.set_pixel(2,0,9)
      display.set_pixel(1,0,9)
      # display.set_pixel(0,0,9)
      sleep(500)

      display.set_pixel(4,0,0)
      display.set_pixel(3,0,0)
      display.set_pixel(2,0,0)
      display.set_pixel(1,0,0)
      # display.set_pixel(0,0,0)
      sleep(500)

      counter=0

  if button_a.is_pressed() and button_b.is_pressed():
    counter = 0

  elif button_a.is_pressed():
    counter = counter + 1
    if counter > 15:
      counter = 15

  elif button_b.is_pressed():
    counter = counter - 1
    if counter < 0:
      counter = 0

  sleep(333)