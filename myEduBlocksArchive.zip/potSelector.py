#
# Pot Selector
#
# Sorry, Pot-Heads, here the word "pot" is an abbreviation for "potentiometer".
#
# This program uses a 10K ohm "pot" (aka "potentiometer" or "variable resistor")
# to select among 10 different options. The 10K ohm pot is attached such that
# the wiper arm (center pin) is attached to Microbit pin "1" and for the other
# two pins of the pot, one can go to the Microbit's "3V" pin and the other to
# the "GND" pin. We use the "read.analog()" method to read the pot value into
# a variable, and then use an "if/elif/else" decision tree to determine what
# range that value falls into. When it falls into a particular range, then the
# program will use the "display.set_pixel()" method to turn on one of 10 pixels
# on the top two rows of the Microbit's 5x5 LED display. Additionally, if you
# press Button "A", it will display the range that the pot value fell in, and
# if you press Button "B", it will display the actual pot value read.
#
# This is one of several possible solutions to the "lack of inputs" problem
# with Microbit board. Whether the idea is good for your application is
# another question. Other possibilities include: counting the number of times
# Button "A" (or "B") is pressed within a certain amount of time, connecting
# additional buttons up to the I/O pins of the Microbit, or interfacing a
# real computer keyboard (good luck).
#
# Filename: "potSelector.py"

from microbit import *

pot1Val = 0

rangeSelected = ""

while True:

    pot1Val = pin1.read_analog()

    if pot1Val < 100:
        range = "0 to 99"
        display.clear()
        display.set_pixel(0,0,9)

    elif pot1Val < 200:
        range = "100 to 199"
        display.clear()
        display.set_pixel(1,0,9)

    elif pot1Val < 300:
        range = "200 to 299"
        display.clear()
        display.set_pixel(2,0,9)

    elif pot1Val < 400:
        range = "300 to 399"
        display.clear()
        display.set_pixel(3,0,9)

    elif pot1Val < 500:
        range = "400 to 499"
        display.clear()
        display.set_pixel(4,0,9)

    elif pot1Val < 600:
        range = "500 to 599"
        display.clear()
        display.set_pixel(0,1,9)

    elif pot1Val < 700:
        range = "600 to 699"
        display.clear()
        display.set_pixel(1,1,9)

    elif pot1Val < 800:
        range = "700 to 799"
        display.clear()
        display.set_pixel(2,1,9)

    elif pot1Val < 900:
        range = "800 to 899"
        display.clear()
        display.set_pixel(3,1,9)

    else:
        range = "900 to 1023"
        display.clear()
        display.set_pixel(4,1,9)

    sleep(500)

    if button_a.is_pressed():
        display.scroll("Range: " + range)
        sleep(500)

    if button_b.is_pressed():
        display.scroll("Actual Value: " + str(pot1Val))
        sleep(500)

# EOF