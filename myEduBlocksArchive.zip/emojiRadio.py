#
# Two-Way Emoji Radio Program
#
# Modeled after the "two-way radio emoticon communicator"
# written by "justaboutfine" from Australia.
#
# This program was written using Edublocks for Microbit.
#
# The Edublocks version is a file called "emojiRadio.xml".
#
# This makes for quite a nice "radio" demo program for my
# Microbit / MicroPython students. It is also a good intro
# to Python "lists" (aka "arrays"). The messages sent between
# radios is just the index number of the emoji (image) into
# my array of images appropriately named "images".
#
# This program only has been tested with 2 Microbit radios.
# Not sure how well it will work with a classroom full of
# users. Might me best to pair students and assign each pair
# of students their own channel number.
#

# Filename: "emojiRadio.py"

from microbit import *
import radio

myTarget = Image("09990:90009:90909:90009:09990")
okImage = Image("05000:50909:50990:05990:00909")
winkImage = Image("00000:09099:00000:90009:09990")

images = []

# Notice you can mix user-defined images with pre-defined images.
images.append(myTarget)
images.append(Image.HEART)
images.append(Image.ASLEEP)
images.append(Image.HAPPY)
images.append(Image.MEH)
images.append(Image.SAD)
images.append(Image.SILLY)
images.append(Image.CONFUSED)
images.append(Image.FABULOUS)
images.append(Image.SURPRISED)
images.append(Image.ANGRY)
images.append(winkImage)
images.append(okImage)
images.append(Image.YES)
images.append(Image.NO)

indexNum = 0

radio.config(channel=10)
radio.on()

while True:
    incomingMessage = radio.receive()

    if button_b.is_pressed():
        indexNum = indexNum - 1
        if indexNum < 0:
            indexNum=0

    if button_a.is_pressed():
        indexNum = indexNum + 1
        if indexNum > len(images) - 1:
            indexNum = len(images) - 1

    if button_a.is_pressed() and button_b.is_pressed():
        radio.send(str(indexNum))

    if incomingMessage:
        display.show(myTarget)
        sleep(500)
        display.show(images[int(incomingMessage)])
        sleep(2000)

    sleep(500)
    display.show(images[indexNum])

# EOF