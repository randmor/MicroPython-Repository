#
# Three LED Binary Counter
#
# This program requires three external LEDs and current limiting
# resistors (220 ohm to 1K ohn) connected to Microbit pins 0, 1 and 2.
# The "far end" of the three resistors must connect to the Microbit's
# GND pin (common ground). Make pin 0 the MSBit, pin 2 the LSBit, where
# MS = Most Significant, and LS = Least Significant.
#
# With 3 display LEDs, we can make a counter that can count up to 7.
# We can display these counts on the 3 external LEDs to show how
# binary numbers work. The user can press button "A" to increment
# the counter, or press button "B" to decrement the counter, or
# press both buttons to reset the counter to zero.
#
# Filename: "3LED-BinaryCounter.py"


from microbit import *

counter = 0

while True:

    # Display count as a 3-bit binary number
    if counter == 0:
        pin2.write_digital(0)
        pin1.write_digital(0)
        pin0.write_digital(0)

    elif counter == 1:
        pin2.write_digital(1)
        pin1.write_digital(0)
        pin0.write_digital(0)

    elif counter == 2:
        pin2.write_digital(0)
        pin1.write_digital(1)
        pin0.write_digital(0)

    elif counter == 3:
        pin2.write_digital(1)
        pin1.write_digital(1)
        pin0.write_digital(0)

    elif counter == 4:
        pin2.write_digital(0)
        pin1.write_digital(0)
        pin0.write_digital(1)

    elif counter == 5:
        pin2.write_digital(1)
        pin1.write_digital(0)
        pin0.write_digital(1)

    elif counter == 6:
        pin2.write_digital(0)
        pin1.write_digital(1)
        pin0.write_digital(1)

    elif counter == 7:
        pin2.write_digital(1)
        pin1.write_digital(1)
        pin0.write_digital(1)

    else:     # Should not get here.

        # On error, blink all 3 LEDs on and then off 3 times
        # then reset counter to zero.
        for i in range(3):

            # Blink-on 3 LEDs
            pin2.write_digital(1)
            pin1.write_digital(1)
            pin0.write_digital(1)
            sleep(500)

            # Blink-off 3 LEDs
            pin2.write_digital(0)
            pin1.write_digital(0)
            pin0.write_digital(0)
            sleep(500)

            # Reset counter
            counter = 0

    # If both buttons pressed, reset counter to zero.
    if button_a.is_pressed() and button_b.is_pressed():
        counter = 0

    # If Button "A" pressed, increment counter
    elif button_a.is_pressed():
        counter = counter + 1
        if counter > 7:
            counter = 7     # Don't let counter go above 7

    # If Button "B" pressed, decrement counter
    elif button_b.is_pressed():
       counter = counter - 1
       if counter < 0:
            counter = 0     # Don't let counter go below 0

    # debug code:
    print(counter)

    sleep(333)

# EOF