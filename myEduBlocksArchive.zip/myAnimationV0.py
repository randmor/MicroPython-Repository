#
# Before "myAnimationV1.xml" and "myAnimationV1.py" I played around with
# the idea of doing animation of geometric patterns on the Microbit's
# 5x5 red LED matrix display with this program, which I am renaming
# "myAnimationV0.py". This listing actually contains 3 programs, two
# of which were commented out. By studying these 3 programs, you can
# see some of the ideas I was playing with to create the array of
# user defined images, then using a "for" loop to show the frames
# in sequence. This program is a good demo of using Python lists
# (aka 'arrays').
#
# ----------------------------------------------
#
# Simple pixel animation for Microbit 5x5 LED matrix display.
#     Demo the use of user-defined images using Image() function.
#     Demo the use a Python list to create an array of frames (our images).
#     Demo the use of a "for loop" to cycle through our list of frames
# so they can be displayed using the display.show() and sleep() functions.
#
# This source file actually includes 3 versions of the program with
# versions 1 and 2 commented out using MicroPythons multi-line comment marks
# (''') which must appear before and after the lines you want commented out.
#
# Try all 3 versions, and make some changes to the frame pixel patterns,
# the number of frames (add some more for a more complex animations sequence),
# and modify delay (sleep) time. And have fun!
#
# Filename: "myAnimationV0.py"

from microbit import *

'''
# Version 1: (Works OK!)

# Define each frame image for our animation sequence.
frame1 = Image("22222:20002:20002:20002:22222")
frame2 = Image("22222:20002:20902:20002:22222")
frame3 = Image("22222:20902:29092:20902:22222")
frame4 = Image("22222:29092:20902:29092:22222")
frame5 = Image("22222:29992:29992:29992:22222")

# Define a list for our user-defined frames
myFrames = [frame1, frame2, frame3, frame4, frame5]

while True:
    # Use this for loop to increment thru our list of images
    # displaying each one, pausing and displaying the next...
    for i in range(0,5):
        #display.show(i)            # Display value of index "i"
        display.show(myFrames[i])
        sleep(500)

'''


'''
# Version 2: Using the list class 'append()' function (Works OK!)

# Define each frame image for our animation sequence.
frame1 = Image("22222:20002:20002:20002:22222")
frame2 = Image("22222:20002:20902:20002:22222")
frame3 = Image("22222:20902:29092:20902:22222")
frame4 = Image("22222:29092:20902:29092:22222")
frame5 = Image("22222:29992:29992:29992:22222")

# Create an empty list, call it "myFrames"
myFrames = []

# Load our user-defined frames into our list of frames (aka "array of frames")
myFrames.append(frame1)
myFrames.append(frame2)
myFrames.append(frame3)
myFrames.append(frame4)
myFrames.append(frame5)

while True:
    # Use this for loop to increment thru our list of images
    # displaying each one, pausing and displaying the next...
    for img in myFrames:
        display.show(img)
        sleep(500)

'''


# Version 3: Using the list class 'append()' function and defining frames
# at same time we append them to our list (array of frames).  (Works OK!)

# create an empty list, call it 'myFrames'.
myFrames = []

# Define each frame image and store them in our 'myFrames' list
myFrames.append(Image("22222:20002:20002:20002:22222"))
myFrames.append(Image("22222:20002:20902:20002:22222"))
myFrames.append(Image("22222:20902:29092:20902:22222"))
myFrames.append(Image("22222:29092:20902:29092:22222"))
myFrames.append(Image("22222:29992:29992:29992:22222"))

while True:
    # Use this for loop to increment thru our list of images
    # displaying each one, pausing and displaying the next...
    for img in myFrames:
        display.show(img)
        sleep(250)


#EOF