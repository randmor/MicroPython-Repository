#
# Two Team Score Keeper (V1C)
#
# This program allows you to keep the score at games where two teams
# are playing against each other. This program has the following five
# functions:
#
#  1.) Increment Team-A's score by 1  (hold Microbit "flat" and press button "A")
#  2.) Decrement Team-A's score by 1  (tilt Microbit "up" and press button "A")
#  3.) Increment Team-B's score by 1  (hold Microbit "flat" and press button "B")
#  4.) Decrement Team-B's score by 1  (tilt Microbit "up" and press button "B")
#  5.) Display scores of both teams   (press buttons "A" and "B" simultaneously)
#
# This program has a EduBlocks version called "twoTeamScoreKeeper.xml".
#
# Originally, this program used the "shake" gesture plus either button "A" or
# button "B" to decrement the respective team's score. However, for whatever
# the reason, "shake" did not work very reliably. After working on other
# "fixes" and alternate gestures, I have decided to use the "up" gesture to
# indicate that the operation will decrement the team's score (as indicated by
# which button is pressed.) So, generally, you should be holding the Microbit
# board "flat" (i.e. such that the 5x5 display is parallel to the ground) when
# you want to incrment a score. Then, to perform a decrement operation, point
# the top edge of the Microbit (the side with the micro-USB connector) up and
# then press a button to decrement that team's score. I will re-edit the .xml
# (EduBlocks) version of this program to use the "up" gesture.
#
# Filename: "twoTeamScoreKeeper1C.py"

from microbit import *

team_A_score = 0
team_B_score = 0

display.show(Image.HAPPY)
sleep(2000)

display.clear()

while True:
    # If user presses buttons "A" and "B" at the same time, display scores for both teams
    # regardless of whether or not an "up" gesture has also occured.
    if button_a.is_pressed() and button_b.is_pressed():
        display.scroll("A=" + str(team_A_score))
        display.scroll("B=" + str(team_B_score))

    # Check for a "up" gesture from the accelerometer
    # If an "up" gesture occurs while either button "A" is pressed,
    # or while button "B" is pressed, that means to DECREMENT that
    # team's score by 1.
    # If no "up" gesture, then pressing on button "A" will cause
    # team A's score to INCREMENT by 1, and pressing on button "B"
    # will cause team B's score to INCREMENT by 1.

    gesture = accelerometer.current_gesture()

    # debug code:
    print(gesture)    # View print() output using REPL in Mu Editor

    # If Microbit is held flat AND button "A" is pressed, then
    # INCREMENT & display team A's new score.
    if button_a.is_pressed() and gesture != "up":
        team_A_score = team_A_score + 1
        display.scroll(team_A_score)

    # If Microbit is tilted "up" AND button "A" is pressed, then
    # DECREMENT & display team A's new score.
    if button_a.is_pressed() and gesture == "up":
        team_A_score = team_A_score - 1
        display.scroll(team_A_score)

    # If Microbit is held flat AND button "B" is pressed, then
    # INCREMENT & display team B's new score.
    if button_b.is_pressed() and gesture != "up":
        team_B_score = team_B_score + 1
        display.scroll(team_B_score)

    # If Microbit is tilted "up" AND button "B" is pressed, then
    # DECREMENT & display team B's new score.
    if button_b.is_pressed() and gesture == "up":
        team_B_score = team_B_score - 1
        display.scroll(team_B_score)

    sleep(200)

# EOF






