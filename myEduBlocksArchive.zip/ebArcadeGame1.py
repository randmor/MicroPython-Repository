#
# Code generated from EduBlocks.
# Same program as "arcadeGame1.py", except generated from an EduBlocks
# progam I modeled after "arcadeGame1.py". After cut/paste of code from
# EduBlocksinto the Mu editor, I made some mods like adding comments,
# white space and expanding indents from 2 spaces to 4 spaces. I tested
# the code, seems to run fine.
#
# Filename: "ebArcadeGame1.py"  [EduBlocks version is "ebArcaseGame1.xml"]

from microbit import *
import random

player_x = 2
enemy_x = random.randint(0, 4)
enemy_y = 0

while True:
    # Display Section
    display.clear()
    display.set_pixel(player_x, 4, 5)
    display.set_pixel(enemy_x, enemy_y, 5)

    # Consequences Section
    if enemy_y == 4 and enemy_x == player_x:
        break

    # Movements Section
    if button_a.was_pressed() and player_x > 0:
        player_x = player_x - 1
    if button_b.was_pressed() and player_x < 4:
        player_x = player_x + 1
    enemy_y = enemy_y + 1      # Update enemy's position
    if enemy_y > 4:
        enemy_y = 0
        enemy_x = random.randint(0, 4)

    sleep(250)

display.show(Image.NO)
sleep(500)
display.scroll("GAME OVER")

# EOF