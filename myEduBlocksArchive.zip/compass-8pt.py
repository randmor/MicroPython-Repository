#
# My 8-Point Compass Program
#
# This program divides the compass rose into 8 points (N, NE, E, SE,
# S, SW, W, and NW) and depending on the reading it receives from
# the Microbit's magnitometer, it will display the letter (or pair
# of letters) that correspond to the direction the Microbit is
# "pointing" to. The pointer on the Microbit is the micro-USB
# connector on the fromt side of the Microbit board. As with all
# programs with the Microbit, the magnitometer has to be calibrated
# compass relative to the Earth's magnetic field using the
# "compass.calibrate()" method. But, this annoying process only has
# to be done one time when the Microbit is powered up. Thus, the
# "if compass.is_calibrated():" test is used to save you from having
# to calibrate every time you have to re-run your program.
#
# Filename:  "compass-8pt.py"


from microbit import *

if compass.is_calibrated():
    compass.calibrate()

while True:

    direction = compass.heading()

    if direction < 22.5:       # 0 to 22.5 degrees we'll call "North"
        display.scroll(" N ")

    elif direction < 67.5:      # 22.5 to 67.5 degrees we'll call "NorthEast"
        display.scroll(" NE ")

    elif direction < 112.5:     # 67.5 to 112.5 degrees we'll call "East"
        display.scroll(" E ")

    elif direction < 157.5:     # 112.5 to 157.5 degrees we'll call "SouthEast"
        display.scroll(" SE ")

    elif direction < 202.5:     # 157.5 to 202.5 degrees we'll call "South"
        display.scroll(" S ")

    elif direction < 247.5:     # 202.5 to 247.5 degrees we'll call "SouthWest"
        display.scroll(" SW ")

    elif direction < 292.5:     # 247.5 to 292.5 degrees we'll call "West"
        display.scroll(" W ")

    elif direction < 337.5:     # 292.5 to 337.5 degrees we'll call "NorthWest"
        display.scroll(" NW ")

    else:                       # 337.5 to 360 degrees we'll also call "North"
        display.scroll(" N ")

    sleep(500)

# EOF