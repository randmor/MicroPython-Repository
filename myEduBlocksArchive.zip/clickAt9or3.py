#
# The game "Click At 9 or 3" uses the Image.ALL_CLOCKS collection of
# predefined images to provide a user interface that looks much like
# a minimalist's clock face. But in the game, it acts more like a
# pendulum that reverses directions when the clock hand reaches the
# 12 o'clock position. When the pendulum swings in the clockwise
# direction, the player must use the "A" button and click it when
# the clock hand is "on 9" to score a point. If you miss you'll loose
# a point. When the pendulum swings in the counter-clockwise direction,
# the player must use the "B" button and click it when the clock hand
# is "on 3" to score a point. Again, if you miss, you will loose a point.
# You have 12 rounds per game where a "round" includes both a clock-wise
# and a counter-clockwise pass of the pendulum. To make game play a bit
# more challenging, the speed of the pendulum has been randomized. Try
# the game with friends to see who can rack up the most points.
#
#
# Filename: "clickAt9or3.py"

from microbit import *
import random

delay = [600, 550, 500, 450, 400, 350, 300, 250, 200, 150]

score = 0
roundCounter = 0
MAX_ROUNDS = 12

while True:
    speed = random.randint(0,9)

    for i in range(0, 12, 1):
        display.show(Image.ALL_CLOCKS[i])
        sleep(delay[speed])
        if button_a.is_pressed():
            if i == 9:
                display.show(Image.HAPPY)
                score = score + 1
            else:
                display.show(Image.SAD)
                score = score - 1
            sleep(500)

    for i in range(11, 0, -1):
        if i == 11:
            display.show(Image.ALL_CLOCKS[0])
            sleep(delay[speed])
        display.show(Image.ALL_CLOCKS[i])
        sleep(delay[speed])
        if button_b.is_pressed():
            if i == 3:
                display.show(Image.HAPPY)
                score = score + 1
            else:
                display.show(Image.SAD)
                score = score - 1
            sleep(500)

    roundCounter = roundCounter + 1
    print(roundCounter)
    if roundCounter > MAX_ROUNDS - 1:
        break

# End of "while True:" loop

display.scroll("Game Over!")
display.scroll("Final score: " + str(score))


# EOF


